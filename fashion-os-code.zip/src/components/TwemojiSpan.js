import { useEffect, useRef } from "react";
import twemoji from "@twemoji/api";

export function TwemojiSpan({ emoji, size = 32 }) {
  const ref = useRef(null);

  useEffect(() => {
    if (ref.current) {
      twemoji.parse(ref.current, {
        folder: "svg",
        ext: ".svg",
        base: "https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/",
        className: "twemoji-img",
      });
    }
  }, [emoji]);

  return (
    <span
      ref={ref}
      style={{ display: "inline-flex", alignItems: "center", justifyContent: "center" }}
    >
      <style>{`.twemoji-img { width: ${size}px; height: ${size}px; }`}</style>
      {emoji}
    </span>
  );
}
